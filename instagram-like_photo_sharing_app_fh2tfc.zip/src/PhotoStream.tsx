import { useCallback, useRef, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { useToast } from "./hooks/use-toast";
import { Id } from "../convex/_generated/dataModel";

type StreamPhoto = {
  url: string;
  _id: Id<"photos">;
  _creationTime: number;
  storageId: Id<"_storage">;
  authorId: Id<"users">;
  likes: number;
  authorEmail: string;
  isLiked: boolean;
};

type MyPhoto = {
  url: string;
  _id: Id<"photos">;
  _creationTime: number;
  storageId: Id<"_storage">;
  authorId: Id<"users">;
  likes: number;
};

export function PhotoStream({ mode }: { mode: "stream" | "my" }) {
  const generateUploadUrl = useMutation(api.photos.generateUploadUrl);
  const createPhoto = useMutation(api.photos.createPhoto);
  const photos = useQuery(
    mode === "stream" ? api.photos.listStream : api.photos.listMyPhotos
  ) as (typeof mode extends "stream" ? StreamPhoto[] : MyPhoto[]) | undefined;
  const toggleLike = useMutation(api.photos.toggleLike);
  const deletePhoto = useMutation(api.photos.deletePhoto);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = useCallback(async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Error",
        description: "Please upload an image file",
        variant: "destructive",
      });
      return;
    }

    // Create a canvas to resize the image
    const img = new Image();
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d")!;

    img.onload = async () => {
      // Calculate new dimensions
      let width = img.width;
      let height = img.height;
      const maxSize = 800;

      if (width > height) {
        if (width > maxSize) {
          height = (height * maxSize) / width;
          width = maxSize;
        }
        // Crop to square
        const offset = (width - height) / 2;
        width = height;
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, offset, 0, height, height, 0, 0, width, height);
      } else {
        if (height > maxSize) {
          width = (width * maxSize) / height;
          height = maxSize;
        }
        // Crop to square
        const offset = (height - width) / 2;
        height = width;
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, offset, width, width, 0, 0, width, height);
      }

      // Convert to blob
      canvas.toBlob(async (blob) => {
        if (!blob) return;

        try {
          // Get the upload URL
          const uploadUrl = await generateUploadUrl();
          
          // Upload the image
          const result = await fetch(uploadUrl, {
            method: "POST",
            headers: { "Content-Type": file.type },
            body: blob,
          });
          const { storageId } = await result.json();
          
          // Create the photo record
          await createPhoto({ storageId });
          
          toast({
            title: "Success",
            description: "Photo uploaded successfully",
          });
        } catch (error) {
          toast({
            title: "Error",
            description: "Failed to upload photo",
            variant: "destructive",
          });
        }
      }, file.type);
    };

    img.src = URL.createObjectURL(file);
  }, [generateUploadUrl, createPhoto, toast]);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFile(file);
    }
  }, [handleFile]);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  if (photos === undefined) {
    return (
      <div className="flex justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-500" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragging ? "border-indigo-500 bg-indigo-50" : "border-gray-300"
        }`}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          type="file"
          accept="image/*"
          className="hidden"
          ref={fileInputRef}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) {
              handleFile(file);
            }
          }}
        />
        <p className="text-gray-500">
          Drag and drop an image here, or click to select one
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {photos.map((photo) => (
          <div
            key={photo._id}
            className="relative aspect-square rounded-lg overflow-hidden group"
          >
            <img
              src={photo.url}
              alt=""
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
              <div className="w-full flex justify-between items-center text-white">
                {mode === "stream" ? (
                  <>
                    <span>{(photo as StreamPhoto).authorEmail}</span>
                    <button
                      onClick={() => toggleLike({ photoId: photo._id })}
                      className="flex items-center gap-2"
                    >
                      <span>{photo.likes}</span>
                      {(photo as StreamPhoto).isLiked ? (
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6">
                          <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                        </svg>
                      ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                        </svg>
                      )}
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => deletePhoto({ photoId: photo._id })}
                    className="text-red-500 hover:text-red-400"
                  >
                    Delete
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
