import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "./components/ui/toaster";
import { PhotoStream } from "./PhotoStream";
import { useState } from "react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"stream" | "my">("stream");

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">PhotoShare</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-3xl mx-auto">
          <Content activeTab={activeTab} setActiveTab={setActiveTab} />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content({ 
  activeTab,
  setActiveTab
}: { 
  activeTab: "stream" | "my";
  setActiveTab: (tab: "stream" | "my") => void;
}) {
  return (
    <div className="flex flex-col gap-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold accent-text mb-4">PhotoShare</h1>
        <Authenticated>
          <div className="flex justify-center gap-4 mb-8">
            <button
              className={`px-4 py-2 rounded-full ${
                activeTab === "stream"
                  ? "bg-indigo-500 text-white"
                  : "bg-gray-100"
              }`}
              onClick={() => setActiveTab("stream")}
            >
              Stream
            </button>
            <button
              className={`px-4 py-2 rounded-full ${
                activeTab === "my"
                  ? "bg-indigo-500 text-white"
                  : "bg-gray-100"
              }`}
              onClick={() => setActiveTab("my")}
            >
              My Photos
            </button>
          </div>
          <PhotoStream mode={activeTab} />
        </Authenticated>
        <Unauthenticated>
          <p className="text-xl text-slate-600 mb-8">Sign in to share photos</p>
          <SignInForm />
        </Unauthenticated>
      </div>
    </div>
  );
}
