import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Id } from "./_generated/dataModel";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.storage.generateUploadUrl();
  },
});

export const createPhoto = mutation({
  args: {
    storageId: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("photos", {
      storageId: args.storageId,
      authorId: userId,
      likes: 0,
    });
  },
});

export const listStream = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const photos = await ctx.db.query("photos").order("desc").collect();
    
    const photosWithMetadata = await Promise.all(
      photos.map(async (photo) => {
        const url = await ctx.storage.getUrl(photo.storageId);
        const author = await ctx.db.get(photo.authorId);
        const isLiked = (await ctx.db
          .query("likes")
          .withIndex("by_photo_user", (q) =>
            q.eq("photoId", photo._id).eq("userId", userId)
          )
          .unique()) !== null;

        return {
          ...photo,
          url,
          authorEmail: author?.email ?? "Unknown",
          isLiked,
        };
      })
    );

    return photosWithMetadata;
  },
});

export const listMyPhotos = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const photos = await ctx.db
      .query("photos")
      .withIndex("by_author", (q) => q.eq("authorId", userId))
      .collect();

    return Promise.all(
      photos.map(async (photo) => ({
        ...photo,
        url: await ctx.storage.getUrl(photo.storageId),
      }))
    );
  },
});

export const deletePhoto = mutation({
  args: {
    photoId: v.id("photos"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const photo = await ctx.db.get(args.photoId);
    if (!photo) throw new Error("Photo not found");
    if (photo.authorId !== userId) throw new Error("Not authorized");

    // Delete associated likes
    const likes = await ctx.db
      .query("likes")
      .withIndex("by_photo_user", (q) => q.eq("photoId", args.photoId))
      .collect();
    
    for (const like of likes) {
      await ctx.db.delete(like._id);
    }

    // Delete the photo from storage and database
    await ctx.storage.delete(photo.storageId);
    await ctx.db.delete(args.photoId);
  },
});

export const toggleLike = mutation({
  args: {
    photoId: v.id("photos"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const existing = await ctx.db
      .query("likes")
      .withIndex("by_photo_user", (q) =>
        q.eq("photoId", args.photoId).eq("userId", userId)
      )
      .unique();

    if (existing) {
      await ctx.db.delete(existing._id);
      await ctx.db.patch(args.photoId, {
        likes: (await ctx.db.get(args.photoId))!.likes - 1,
      });
    } else {
      await ctx.db.insert("likes", {
        photoId: args.photoId,
        userId,
      });
      await ctx.db.patch(args.photoId, {
        likes: (await ctx.db.get(args.photoId))!.likes + 1,
      });
    }
  },
});
